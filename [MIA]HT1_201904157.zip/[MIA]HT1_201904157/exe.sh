g++ main.cpp
./a.out